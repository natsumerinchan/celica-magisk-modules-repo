# Fake_Sudo
 Use a fake sudo on Android shell.
