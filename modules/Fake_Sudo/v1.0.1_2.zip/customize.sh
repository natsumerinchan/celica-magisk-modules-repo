SKIPUNZIP=0

# Set permissions
ui_print "- Setting permissions"
set_perm $MODPATH/system/bin/sudo 0 2000 0755
